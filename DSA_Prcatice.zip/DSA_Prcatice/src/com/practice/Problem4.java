package com.practice;

public class Problem4 {

	public static void main(String[] args) {

		for(int i=1;i<100;i+=2) {
			System.out.println(i);
		}
	}

}
