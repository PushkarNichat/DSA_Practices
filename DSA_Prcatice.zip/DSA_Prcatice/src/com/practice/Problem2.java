package com.practice;

public class Problem2 {

	public static void main(String[] args) {
		
		String name="Prajwal";
		
		
		for (int i=0;i<100;i++) {
			if(i%3==0 || i%6==0)
			{
				System.out.println(name);
			}
		
		}
		
		
	}

}
