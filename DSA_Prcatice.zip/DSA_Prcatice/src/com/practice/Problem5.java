package com.practice;

public class Problem5 {

	public static void main(String[] args) {

		String name= "Prajwal";
		;
		
		
	}

}
